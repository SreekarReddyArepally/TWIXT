#include "func.h"
#include<stdio.h>
#include<stdlib.h>

void initboard(char board[24][24]){
    for(int i=0;i<24;i++){
        for(int j=0;j<24;j++){
            board[i][j]='.';
        }
    }
    board[0][0]=' ';
    board[0][23]=' ';
    board[23][0]=' ';
    board[23][23]=' ';
}

void printPeg(char c, int linked) {
    if (c == 'R') {
        if (linked) {
            /*linked? magenta, no red*/
            printf("\x1b[35m%c\x1b[0m", c);
        } else {
            printf("\x1b[31m%c\x1b[0m", c);
        }
    } else if (c == 'B') {
        if (linked) {
            /*linked? cyan, no blue*/
            printf("\x1b[36m%c\x1b[0m", c);
        } else {
            printf("\x1b[34m%c\x1b[0m", c);
        }
    } else {
        printf("%c", c);
    }
}

void PrintBoard(char board[24][24],char cords,node*links[24][24]){
    for(int i=0;i<24;i++){
        if(i==0){
            printf("  ");
            for(int k=0;k<24;k++){
                if(k==0)
                    printf(" \x1b[32m%c\x1b[0m  ",cords++);
                else if(k==23)   
                    printf("  \x1b[32m%c\x1b[0m ",cords++);
                else
                    printf(" \x1b[32m%c\x1b[0m ",cords++);

            }
            cords=65;
            printf("\n");   
        }
        if(i<10){
            printf(" \x1b[32m%d\x1b[0m",i);
        }
        else{
            printf("\x1b[32m%d\x1b[0m",i);
        }
        
        for(int j=0;j<24;j++){
            int linked = (links[i][j] != NULL);
            if(j==0&&(i!=0&&i!=23)) {
                printf(" ");
                printPeg(board[i][j], linked);
                printf(" \x1b[34m|\x1b[0m");
            }
            else if(j==23&&(i!=0&&i!=23)) {
                printf("\x1b[34m|\x1b[0m ");
                printPeg(board[i][j], linked);
                printf(" ");
            }
            else{
                if(j==0||j==23){
                    printf(" ");
                }
                printf(" ");
                printPeg(board[i][j], linked);
                printf(" ");
            }
        }
        if(i<10){
            printf("\x1b[32m%d\x1b[0m ",i);
        }
        else{
            printf("\x1b[32m%d\x1b[0m",i);
        }
        printf("\n");
        if(i==0){
            printf("      ");
            for(int k=1;k<67;k++){
                printf("\x1b[31m=\x1b[0m");
            }
            printf("\n");
        }
        if(i==22){
            printf("      ");
            for(int k=1;k<67;k++){
                printf("\x1b[31m=\x1b[0m");
            }
            printf("\n");
        }
        if(i==23){
            printf("  ");
            for(int k=0;k<24;k++){
                if(k==0)
                    printf(" \x1b[32m%c\x1b[0m  ",cords++);
                else if(k==23)   
                    printf("  \x1b[32m%c\x1b[0m ",cords++);
                else
                    printf(" \x1b[32m%c\x1b[0m ",cords++);
            }
            printf("\n");
        }
        
    }   
}

void printdesign(){
    printf("\x1b[33m==============================================================================\n");
    printf("\x1b[33m    W   W  EEEEE  L     CCCCC  OOOOO  M   M  EEEEE     TTTTT  OOOOO\x1b[0m\n");
    printf("\x1b[33m    W   W  E      L     C      O   O  MM MM  E           T    O   O\x1b[0m\n");
    printf("\x1b[33m    W W W  EEEEE  L     C      O   O  M M M  EEEEE       T    O   O\x1b[0m\n");
    printf("\x1b[33m    WW WW  E      L     C      O   O  M   M  E           T    O   O\x1b[0m\n");
    printf("\x1b[33m    W   W  EEEEE  LLLLL CCCCC  OOOOO  M   M  EEEEE       T    OOOOO\x1b[0m\n");
    printf("\n\n");
    printf("\x1b[33m                  TTTTT  W   W  IIIII  X   X  TTTTT\x1b[0m\n");
    printf("\x1b[33m                    T    W   W    I     X X     T\x1b[0m\n");
    printf("\x1b[33m                    T    W W W    I      X      T\x1b[0m\n");
    printf("\x1b[33m                    T    WW WW    I     X X     T\x1b[0m\n");
    printf("\x1b[33m                    T    W   W  IIIII  X   X    T\x1b[0m\n");
    printf("\x1b[33m==============================================================================\x1b[0m");
    printf("\n\n");
}

void insert(int r1,int c1,int r2,int c2,node *links[24][24]){
    node *new1=malloc(sizeof(node));
    new1->r=r2;
    new1->c=c2;
    new1->next=NULL;
    if(links[r1][c1]==NULL){
        links[r1][c1]=new1;
        return;
    }
    node *temp=links[r1][c1];
    while(temp->next!=NULL){
        temp=temp->next;
    }
    temp->next=new1;
    return;
}

int line(int r1,int c1,int r2, int c2,int x,int y){
    if(r2-r1>0)
        return (y-c1)*(r2-r1) - (c2-c1)*(x-r1);
    return (c2-c1)*(x-r1) - (y-c1)*(r2-r1);
}
/*we basically need to check if they lie on opp sides or not, we need to do it twice cuz links are line segs*/

/*for overlapping links*/
int overlap(int r1,int c1,int r2,int c2,int r3,int c3,int r4,int c4){
    int p1=line(r1,c1,r2,c2,r3,c3);
    int p2=line(r1,c1,r2,c2,r4,c4);
    if(p1*p2<0){
        /*C and D lie opp, might intersect, check the same for A and B*/
        int p3=line(r3,c3,r4,c4,r1,c1);
        int p4=line(r3,c3,r4,c4,r2,c2);
        if(p3*p4<0){
            /*only place the last peg---D*/
            printf("peg placed, no link possible.\n");
            /*deff intersect, so cant be linked*/
        }
        else{
            /*dont intersect, link C and D*/
            return 0;
        }
    }
    else{
        /*link C and D as lie on the same side as A and B, hence dont intersect*/
        return 0;
    }
    return 1;
}

int path(char b[24][24],node *links[24][24],int r1,int c1,int r2,int c2){   
    int minr=(r1>r2)?r2:r1-1;
        minr=(minr<0)?0:minr;
    int maxr=(r1<r2)?r2:r1;
        maxr=(maxr>=24)?23:maxr;
    int minc=(c1>c2)?c2:c1;
        minc=(minc<0)?0:minc;
    int maxc=(c1<c2)?c2:c1;
        maxc=(maxc>=24)?23:maxc;

    for(int i=minr;i<maxr;i++){
        for(int j=minc;j<maxc;j++){
            if(b[i][j]!='.'){
             node *temp=links[i][j];
             while(temp!=NULL){
                if(overlap(r1,c1,r2,c2,i,j,temp->r,temp->c)){
                    /*overlap=1----can't be linked*/
                    return 1;
                }
                temp=temp->next;
             } 
            }
        }
    }
    return 0;
}

int win(char b[24][24],node *links[24][24],int turn){
    char temp=(turn%2==1)?'R':'B';

    int dp[24][24]={};
    for(int i=0;i<24;i++){
        for(int j=0;j<24;j++){
            dp[i][j]=-1;
        }
    }
    /*dp[i][j]---represents if we can reach it from the top border*/

    if(temp=='R'){
        for(int i=1;i<23;i++){
            if(b[0][i]=='R'){
                dp[0][i]=1;
            }
        }
    }
    else{
        for(int i=1;i<23;i++){
            if(b[i][0]=='B'){
                dp[i][0]=1;
            }
        }
    }
    int flag=1;
    while(flag){
        flag=0;
        for(int i=0;i<24;i++){
            for(int j=0;j<24;j++){
                if(b[i][j]==temp && dp[i][j]==-1){
                    node *temp=links[i][j];
                    while(temp!=NULL){
                        if(dp[temp->r][temp->c]==1){
                            dp[i][j]=1;
                            flag=1;
                            break;
                        }
                        temp=temp->next;

                    }
                }
            }
        }
    }
    if(temp=='R'){
        for(int i=1;i<23;i++){
            if(dp[23][i]==1){
                return 1;
            }
        }
    }
    else{
        for(int i=1;i<23;i++){
            if(dp[i][23]==1){
                return 1;
            }
        }
    }
    return 0;
}


