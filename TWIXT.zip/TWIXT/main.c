#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include "func.h"

char board[24][24];

/*COLOURS
BLUE :\x1b[34m  \x1b[0m
RED :\x1b[31m  \x1b[0m
GREEN :\x1b[32m  \x1b[0m
YELLOW : \x1b[33m \x1b[0m
MAGENTA: \x1b[35m \x1b[0m
CYAN: \x1b[36m \x1b[0m
*/

node *links[24][24]; 
/*2d array of pointers whciih store all the linkd pegs of a player, we'll use this for the DFS/win cond*/

int main(){
    initboard(board);
    int difrow[8] = {-2, -2, -1, -1, 1, 1, 2, 2};
    int difcol[8] = {-1, 1, -2, 2, -2, 2, -1, 1};
    int flag=1;
    int valid=0;
    int turn=1;
    printdesign();
    while(1){
        if(flag){
            PrintBoard(board,65,links);
        }

        /*printing for inp*/
        if(turn%2==1){
            printf("\x1b[31mRed's Turn.\x1b[0m\nEnter the Coordinates:");
        }
        else{
            printf("\x1b[34mBlue's Turn.\x1b[0m\nEnter the Coordinates:");
        }

        Board cords;

        if(scanf(" %c%d",&cords.col,&cords.row)!=2){
            while(getchar()!='\n');
            printf("Invalid Input, try again.\n");
            flag=0;
            continue;
        }

        if((cords.col<'A'||cords.col>'X')||(cords.row>23||cords.row<0)){
            printf("Invalid Input, try again.\n");
            flag=0;
            continue;
        }

        else{
            if(turn%2==1){
                if(board[cords.row][cords.col-'A']=='.' && (cords.col!='A'&&cords.col!='X')){
                    board[cords.row][cords.col-'A']='R';
                    turn++;
                    flag=1;
                    valid=1;
                }
                else if(cords.col=='A'||cords.col=='X'){
                    printf("Cannot place \x1b[31mRed\x1b[0m peg at %c column,try again.\n",cords.col);
                    flag=0;
                    valid=0;
                }
                else{
                    printf("Position Occupied, Try again.\n");
                    flag=0;
                    valid=0;
                }
            }
            else{
                if(board[cords.row][cords.col-'A']=='.' && (cords.row!=0&&cords.row!=23)){
                    board[cords.row][cords.col-'A']='B';
                    turn++;
                    flag=1;
                    valid=1;
                }
                else if(cords.row==0||cords.row==23){
                    printf("Cannot place \x1b[34mBlue\x1b[0m peg at %dth row,try again.\n",cords.row);
                    flag=0;
                    valid=0;
                }
                else{
                    printf("Position Occupied, Try again.\n");
                    flag=0;
                    valid=0;
                }
            }
        }
        if(valid){
            for(int k=0; k<8; k++){
                int nrow = cords.row + difrow[k];
                int ncol = (cords.col-'A') + difcol[k];
                if((nrow>=0 && nrow<=23) && (ncol>=0 && ncol<=23)){
                    if(board[nrow][ncol]==board[cords.row][cords.col-'A']){
                        if(path(board,links,cords.row,cords.col-'A',nrow,ncol)==0){
                            insert(cords.row,cords.col-'A',nrow,ncol,links);
                            insert(nrow,ncol,cords.row,cords.col-'A',links);
                            if(turn%2==0)
                                printf("Linked pegs \x1b[31m%c%d\x1b[0m & \x1b[31m%c%d\x1b[0m\n",cords.col,cords.row,(char)(ncol+'A'),nrow);
                            else
                                printf("Linked pegs \x1b[34m%c%d\x1b[0m & \x1b[34m%c%d\x1b[0m\n",cords.col,cords.row,(char)(ncol+'A'),nrow);
                        }
                    }
                }
            }
        }
        int over=win(board,links,turn-1);
        if(over){
            printf("\x1b[33m=====GAME OVER=====\x1b[0m\n");
            if(turn%2==0)
                printf("\x1b[31mRED WON!!!!\x1b[0m\n");
            else
                printf("\x1b[34mBLUE WON!!!!\x1b[0m\n");
            printf("\x1b[33m===================\x1b[0m\n");
            PrintBoard(board,65,links);
            break;
        }
    }
}

