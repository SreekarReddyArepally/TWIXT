#ifndef FUNC_H
#define FUNC_H

#include <stdio.h>
#include <stdlib.h>

typedef struct Board{
    char col;
    int row;
}Board;

typedef struct node{
    int r;
    int c;
    struct node *next;
}node;

void initboard(char board[24][24]);

void PrintBoard(char board[24][24],char cords,node*links[24][24]);

void printPeg(char c, int isLinked);

void printdesign();

void insert(int r1,int c1,int r2,int c2,node *links[24][24]);

int line(int r1,int c1,int r2, int c2,int x,int y);

int overlap(int r1,int c1,int r2,int c2,int r3,int c3,int r4,int c4);

int path(char b[24][24],node *links[24][24],int r1,int c1,int r2,int c2);

int win(char b[24][24],node *links[24][24],int turn);



#endif  